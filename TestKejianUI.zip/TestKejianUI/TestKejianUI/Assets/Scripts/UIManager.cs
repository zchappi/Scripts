﻿using UnityEngine;
using System.Collections;

public class UIManager : MonoBehaviour
{

	// Use this for initialization
	void Start () {
      GameObject go=  Instantiate(Resources.Load("UI")) as GameObject;
      go.name = "UIM";
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
