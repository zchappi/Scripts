﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIMoveControl : MonoBehaviour
{

    //[SerializeField]
    //private GameObject btn_Open;

    //[SerializeField]
    //private GameObject btn_Close;

    [SerializeField]
    private RectTransform m_MoveTrans;

    private float moveDistance;

    [SerializeField]
    private RectTransform m_Canvas;

    private float moveTime;
    private float snapTime;

    private bool isMoveing;

    private Vector2 targetSizeData;

    //[SerializeField]
    //private Image m_BG_Image;

    // Use this for initialization
    void Start()
    {
        moveDistance = m_Canvas.sizeDelta.x;
        Debug.Log("===moveDistance====" + moveDistance);
    }

    // Update is called once per frame
    void Update()
    {
        if (isMoveing)
        {
            snapTime = Time.realtimeSinceStartup - moveTime;
            m_MoveTrans.sizeDelta = Vector2.Lerp(m_MoveTrans.sizeDelta, targetSizeData, snapTime);
            if (snapTime >= 1)
            {
                isMoveing = false;
            }
        }
    }

    public void OpenUI()
    {
        Debug.Log("openUI");
        //btn_Open.SetActive(false);
        //btn_Close.SetActive(true);
        moveTime = Time.realtimeSinceStartup;
        isMoveing = true;
      //  m_BG_Image.enabled = true;
        targetSizeData = new Vector2(m_Canvas.sizeDelta.x, m_MoveTrans.sizeDelta.y);
    }

    public void HideUI()
    {
        Debug.Log("hideui");
     //   btn_Open.SetActive(true);
     //   btn_Close.SetActive(false);
        moveTime = Time.realtimeSinceStartup;
        isMoveing = true;
     //   m_BG_Image.enabled = false;
        targetSizeData = new Vector2(80, m_MoveTrans.sizeDelta.y);
    }
}
