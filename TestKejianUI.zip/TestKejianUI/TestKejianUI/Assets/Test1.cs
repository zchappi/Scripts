﻿using UnityEngine;
using System.Collections;

public class Test1 : MonoBehaviour {

	// Use this for initialization
    void Awake() {
        Debug.Log("Test1");
    }
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
