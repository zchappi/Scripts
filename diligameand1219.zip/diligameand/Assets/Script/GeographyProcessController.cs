using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using DG.Tweening;
using System.Collections.Generic;
public class GeographyProcessController : MonoBehaviour {
	public GameObject PyObj;//配音
	public GameObject YxObj;//音效
	public AudioClip buttonYx;//按钮声音音频文件
	public OneLevel[] Levels;//关卡
	[System.Serializable]
	public class OneLevel//单个关卡
	{
		public float NextLevelDelayTime;//转跳到下个关卡的延时时间
		public OneOperation[] Operations;//本关卡内的操作
	
	}
	[System.Serializable]
	public class OneOperation//单个操作
	{
		public DoTime OperateDoTime;//操作的执行时间
		public List<int> DoIndex=new List<int>();//在单个正确和错误时填写，指定序号
		public float DelayTime;//操作执行前的延时时间
		public OperateMode operateMode;//操作的类型
		public PlayOneAnimation[] PlayAnimation;//播放动画的列表（包括帧动画和unity内的animation）
		public Move Move;//需要移动物体的列表
		public ScaleChange ScaleChange;//需要做缩放操作的物体
		public GameObject[] ShowGameObject;//需要将setactive设为true的物体
		public GameObject[] HideGameObject;//需要将setactive设为false的物体
		public DestoryObj DestoryGameObject;//需要销毁的物体
		public AudioClip PeiYin;//需要播放的配音文件
		public AudioClip YinXiao;//播放播放的音效文件
		public Image[] ShowImage;//需要将image组件enable设为true的物体
		public Image[] HideImage;//需要将image组件enable设为false的物体
		public SetParent[] SetParent;//需要进行设为父物体操作的列表
		public Nextoperation[] Nextoperation;//当前操作后需要调用的其他操作
	}
	[System.Serializable]
	public enum DoTime//操作的执行时间
	{
		Null,//没有执行时间，一般由其他操作调用
		BeforeBegin,//在游戏开始前调用
		Begin,//游戏开始后调用
		OneRight,//拖对一个时调用
		OneWrong,//拖错一个时调用
		AllRight//全部拖对时调用
	}
	[System.Serializable]
	public enum OperateMode//操作的类型
	{
		BeginGame,//开始游戏
		ExitGame,//退出游戏
		PlayAnimation,//播放动画（包括帧动画和unity内的animation）
		Move,//移动
		ScaleChange,//缩放
		ShowGameObject,//显示物体
		HideGameObject,//隐藏物体
		PlayPeiYin,//播配音
		PlayYinXiao,//播音效
		ShowImage,//显示图片
		HideImage,//隐藏图片
		SetParent,//设置父物体
		DestoryGameObject,//销毁物体
		ClearPaint//清除画布
	}
	[System.Serializable]
	public class PlayOneAnimation//播放动画（包括帧动画和unity内的animation）
	{
		public GameObject AnimationObject;//需要播放动画的物体
		public bool PlayOrStop=true;//播放还是停止 true为播放
	}
	[System.Serializable]
	public class Move//移动
	{
		[System.Serializable]
		public 	enum MoveType//移动类型
		{
			Transform,//3d物体的移动
			RectTransform//UI的移动
		}
		[System.Serializable]
		public enum MoveTo//移动的目标
		{
			Vector3,//具体的坐标
			AimObj//移动到另一个物体处
		}
		public MoveType movetype;
		public MoveTo Moveto;
		public GameObject MoveObj;//需要移动的物体
		public GameObject AimObj;
		public Vector3 AimPos;
		public float speed;//移动的速度 数字越小速度越快
	}
	[System.Serializable]
	public class DestoryObj//销毁
	{
		public bool IsDestoryHasDragObj;
		public GameObject[] objs;//需要销毁的物体
	}
	[System.Serializable]
	public class ScaleChange//缩放
	{
		public GameObject AimObj;//需要缩放的物体
		public Vector3 scale;//要缩放到的大小
		public float Speed;//变化的快慢 数字越小越快
	}
	[System.Serializable]
	public class SetParent//设置父物体
	{
		public GameObject SonObj;//子物体
		public GameObject ParentObj;//父物体
	}
	[System.Serializable]
	public class Nextoperation//调用的下个操作
	{
		public int LevelIndex;//下个操作的关卡序号
		public int OperationIndex;//下个操作的操作序号
	}
	[System.Serializable]
	public class ScrollKuang//拖动框
	{
		public Vector2[] ObjPos;//每一格的位置
		public GameObject scrollrect;//可拖动的区域
		public GameObject LeftButton;//向左按钮
		public GameObject RightButton;//向右按钮
	}
	[HideInInspector]
	public int levelindex=0;//关卡序号
	void Start () {
		MessageBeforeBegin ();
	}
	//执行关卡开始前的操作
	public void MessageBeforeBegin()
	{
		SendMessage ("ResetGameTime");
		SendMessage ("ResetGameScore");
		for (int i=0; i<Levels[levelindex].Operations.Length; i++) {
			if(Levels[levelindex].Operations[i].OperateDoTime==DoTime.BeforeBegin)
				StartCoroutine(DoOneOperation(Levels[levelindex].Operations[i]));
		}
	}
	//执行关卡开始后的操作
	public void MessageBegin()
	{
		print("begin");
		for (int i=0; i<Levels[levelindex].Operations.Length; i++) {
			if(Levels[levelindex].Operations[i].OperateDoTime==DoTime.Begin)
				StartCoroutine(DoOneOperation(Levels[levelindex].Operations[i]));
		}
	}
	//执行单个错误反馈操作
	public void MessageDoWrong(int index)
	{
		print("wrong"+index);
		for (int i=0; i<Levels[levelindex].Operations.Length; i++) {
			if(Levels[levelindex].Operations[i].OperateDoTime==DoTime.OneWrong)
				if(Levels[levelindex].Operations[i].DoIndex.Contains(index))
					StartCoroutine(DoOneOperation(Levels[levelindex].Operations[i]));
		}
	}
	//执行单个正确反馈操作
	public void MessageDoOneRight(int index)
	{
		print("oneright"+index);
		for (int i=0; i<Levels[levelindex].Operations.Length; i++) {
			if(Levels[levelindex].Operations[i].OperateDoTime==DoTime.OneRight)
				if(Levels[levelindex].Operations[i].DoIndex.Contains(index))
					StartCoroutine(DoOneOperation(Levels[levelindex].Operations[i]));
		}
	}
	//执行全部正确之后的反馈操作
	public IEnumerator MessageDoAllRight()
	{
		print("allright");
		for (int i=0; i<Levels[levelindex].Operations.Length; i++) {
			if(Levels[levelindex].Operations[i].OperateDoTime==DoTime.AllRight)
				StartCoroutine(DoOneOperation(Levels[levelindex].Operations[i]));
		}
		if (levelindex < Levels.Length-1) {
			yield return new WaitForSeconds(Levels[levelindex].NextLevelDelayTime);
			levelindex++;
			MessageBeforeBegin();
		}
	}
	//操作执行
	public IEnumerator DoOneOperation(OneOperation operation)
	{
		Debug.Log("start"+operation.operateMode);
		yield return new WaitForSeconds (operation.DelayTime);
		switch (operation.operateMode) {
		case OperateMode.BeginGame:
			SendMessage("Begin");
			break;
		case OperateMode.ExitGame:
			ExitGame();
			break;
		case OperateMode.PlayAnimation:
			StartCoroutine (PlayAnimation (operation));
			break;
		case OperateMode.Move:
			StartCoroutine(DoMove(operation));
			break;
		case OperateMode.ScaleChange:
			StartCoroutine(DoScaleChange(operation));
			break;
		case OperateMode.ShowGameObject:
			StartCoroutine(DoShowOrHideObj(operation,true));
			break;
		case OperateMode.HideGameObject:
			StartCoroutine(DoShowOrHideObj(operation,false));
			break;
		case OperateMode.DestoryGameObject:
			StartCoroutine(DoDestoryGameObject(operation));
			break;
		case OperateMode.PlayPeiYin:
			StartCoroutine(DoPlayPeiyin(operation));
			break;
		case OperateMode.PlayYinXiao:
			StartCoroutine(DoPlayYinXiao(operation));
			break;
		case OperateMode.ShowImage:
			StartCoroutine(DoShowOrHideImage(operation,true));
			break;
		case OperateMode.HideImage:
			StartCoroutine(DoShowOrHideImage(operation,false));
			break;
		case OperateMode.SetParent:
			StartCoroutine(DoSetParent(operation));
			break;
		}
	}

	public IEnumerator PlayAnimation(OneOperation operation)
	{
		for (int i=0; i<operation.PlayAnimation.Length; i++) {
			if(operation.PlayAnimation[i].PlayOrStop)
			{
				operation.PlayAnimation[i].AnimationObject.GetComponent<PlayFlash>().Play();
			}
			else
			{
				operation.PlayAnimation[i].AnimationObject.GetComponent<PlayFlash>().stop();
			}
		}
		if (operation.Nextoperation.Length > 0) {
			foreach(Nextoperation next in operation.Nextoperation)
				StartCoroutine(DoOneOperation(Levels[next.LevelIndex].Operations[next.OperationIndex]));
		}
		yield return null;
	}
	
	public IEnumerator DoMove(OneOperation operation)
	{
		Tweener t = null;
		if (operation.Move.movetype == Move.MoveType.RectTransform) {
			if (operation.Move.Moveto == Move.MoveTo.AimObj)
			{
				t=operation.Move.MoveObj.GetComponent<RectTransform>().DOMove(operation.Move.AimObj.GetComponent<RectTransform>().position,operation.Move.speed);
			} 
			else if (operation.Move.Moveto == Move.MoveTo.Vector3) 
			{
				t=operation.Move.MoveObj.GetComponent<RectTransform>().DOLocalMove(operation.Move.AimPos,operation.Move.speed);
			}
		} else if (operation.Move.movetype == Move.MoveType.Transform) {
			if (operation.Move.Moveto == Move.MoveTo.AimObj) 
			{
				t=operation.Move.MoveObj.transform.DOMove(operation.Move.AimObj.transform.position,operation.Move.speed);
			} 
			else if (operation.Move.Moveto == Move.MoveTo.Vector3) 
			{
				t=operation.Move.MoveObj.transform.DOMove(operation.Move.AimPos,operation.Move.speed);
			}
		}
		t.onComplete = delegate {
			StartCoroutine(DoNextOperation (operation));
		};
		yield return null;
	}
	public IEnumerator DoScaleChange(OneOperation operation)
	{
		Tweener t = operation.ScaleChange.AimObj.transform.DOScale(operation.ScaleChange.scale,operation.ScaleChange.Speed);
		t.onComplete = delegate {
			StartCoroutine(DoNextOperation (operation));
		};
		yield return 0;
	}
	public IEnumerator DoAChange(OneOperation operation)
	{
		Tweener t = operation.ScaleChange.AimObj.transform.DOScale(operation.ScaleChange.scale,operation.ScaleChange.Speed);
		t.onComplete = delegate {
			StartCoroutine(DoNextOperation (operation));
		};
		yield return 0;
	}
	public IEnumerator DoShowOrHideObj(OneOperation operation,bool showorhide)
	{
		if (showorhide) {
			foreach (GameObject g in operation.ShowGameObject)
				g.SetActive (true);
		} else {
			foreach (GameObject g in operation.HideGameObject)
				g.SetActive (false);
		}
		StartCoroutine(DoNextOperation (operation));
		yield return null;
	}
	public IEnumerator DoDestoryGameObject(OneOperation operation)
	{
		if(operation.DestoryGameObject.objs!=null)
		{
			foreach(GameObject g in operation.DestoryGameObject.objs)
				Destroy(g);
		}

		StartCoroutine(DoNextOperation (operation));
		yield return null;
	}
	public IEnumerator DoShowOrHideImage(OneOperation operation,bool showorhide)
	{
		if (showorhide) {
			foreach (Image i in operation.ShowImage)
				i.enabled=true;
		} else {
			foreach (Image i in operation.HideImage)
				i.enabled=false;;
		}
		StartCoroutine(DoNextOperation (operation));
		yield return null;
	}
	
	public IEnumerator DoSetParent(OneOperation operation)
	{
		for (int i=0; i<operation.SetParent.Length; i++) {
			operation.SetParent[i].SonObj.transform.SetParent(operation.SetParent[i].ParentObj.transform);
		}
		StartCoroutine(DoNextOperation (operation));
		yield return null;
	}

	public IEnumerator DoNextOperation(OneOperation operation)
	{
		if (operation.Nextoperation.Length > 0) {
			foreach(Nextoperation next in operation.Nextoperation)
				StartCoroutine(DoOneOperation(Levels[next.LevelIndex].Operations[next.OperationIndex]));
		}
		yield return null;
	}
	public IEnumerator DoPlayPeiyin(OneOperation operation)
	{
		PyObj.GetComponent<AudioSource>().clip = operation.PeiYin;
		PyObj.GetComponent<AudioSource>().Play ();
		yield return null;
	}
	public IEnumerator DoPlayYinXiao(OneOperation operation)
	{
		PyObj.GetComponent<AudioSource>().clip = operation.YinXiao;
		PyObj.GetComponent<AudioSource>().Play ();
		yield return null;
	}

	//播放按钮音效
	public void PlayButtonYx()
	{
		PyObj.GetComponent<AudioSource>().clip = buttonYx;
		PyObj.GetComponent<AudioSource>().Play ();
	}
	//退出游戏
	public void ExitGame()
	{
		print ("ExitGame");
		#if !UNITY_EDITOR
		MDLog.Log("===ExitGame===");
		GameGlobal.m_gamecontrol.ResetParameterWhenBack ();
		#endif
	}
	//显示模型
	public void ShowModel()
	{
		#if !UNITY_EDITOR
		GameGlobal.m_gamecontrol.Gameshowmodel();
		#endif
	}
	//调用指定关卡的指定操作，可以用按钮调用
	public void ButtonClickEvent(int index)
	{
		StartCoroutine(DoOneOperation(Levels[levelindex].Operations[index]));
	}
	//切换关卡
	public void ChangeLevel(int levelindex)
	{
		this.levelindex = levelindex;
		SendMessage ("ChangelevelIndex", levelindex);
		MessageBeforeBegin ();
	}
}
