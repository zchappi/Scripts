using UnityEngine;
using System.Collections;
using UnityEngine.UI; 
using UnityEngine.EventSystems; 
using System.Collections.Generic;
using DG.Tweening;


public class GeographyGameController : MonoBehaviour,IDragHandler,IPointerDownHandler,IPointerUpHandler {
	public Canvas canvas;//画布
	public GameObject m_initCanvas;//临时父物体，保证被拖拽物体不被遮挡
	public GameObject Daixuan;//待选物体，地图轮廓没有移动到待选框之前存放的位置
	private List<int> ChoosenIndex;//在没有答案时是所有没有被放到待选框的图的序号
	private GameObject nowItem=null;//目前被拖拽的物体
	private GameObject nowitemClone=null;//目前被拖拽的物体的克隆
	private Vector3 PrePos=Vector3.zero;//被拖拽物体原来的位置
	private bool isBacking=false;//是否正在错误返回原来位置的途中
	private int nowkuangindex = 0;//当前被拖拽的物体所属待选框的序号，补充待选物体时使用
	private int[] nowshengindex;//目前被选中放入待选框的物体
	private int gamescore;//得分
	private float gametime;//时间
	private bool isbegin=false;//是否已经开始

	public OneLevel[] Levels;//关卡集合
	[HideInInspector]
	public int Levelindex=0;//目前的关卡下标
	[System.Serializable]
	public class OneLevel//单个关卡
	{
		public bool isHaveRightAnswer;//当前关卡是否是要设置答案
		public List<int> answers = new List<int> ();//答案
		public GameObject[] kuang;//待选框，数量可以自定义
		public Text[] names ;//显示名字的text
		public List<GameObject> WhenRightShow = new List<GameObject> ();//当拖对之后显示的物体，需要提前放在正确的位置上
		public GameObject[] shengfensprite ;//省份的图
		public string[] shengfenname ;//省份的名字
		public string[] shenghuiname ;//省会的名字
		public string[] jianchengname ;//省份的简称
		
	}

	public List<int> GetNum(string name)////获取物体标号，物体命名规则xxx-num-num-num，一个位置可以有多个下标，方便交界处和特别小的省份设置
	{ 
		List<int> index = new List<int> ();
		string[] NameNum=name.Split('-');
		for (int i=1; i<NameNum.Length; i++) {
			try{
				int oneindex=int.Parse(NameNum [i]);
				index.Add(oneindex);
			}
			catch{

			}
		}
		return index;
	}
	void Start()
	{
	}
	void Update()
	{
		if (isbegin) 
		{//游戏开始后计时

			gametime += Time.deltaTime;
			text_time.text=gametime.ToString("f2");
		}
	}

	public void Begin()
	{//游戏开始
		ChoosenIndex = new List<int> ();
		//如果有答案，就把非答案的那些地图的序号放到choosenindex里面，如果没有答案则全部放入
		for (int i=0; i<Levels[Levelindex].shengfenname.Length; i++) {
			if(Levels[Levelindex].isHaveRightAnswer)
			{
				if(!Levels[Levelindex].answers.Contains(i))
					ChoosenIndex.Add(i);
			}
			else
				ChoosenIndex.Add(i);
		}
		//将显示名字的text激活，因为所有地图完成之后会隐藏
		for(int i=0;i<Levels[Levelindex].kuang.Length;i++)
		{
			Levels[Levelindex].names[i].enabled=true;
		}
		//初始化当前放入待选框的地图的数组，数量和待选框的数量一致
		nowshengindex = new int[Levels [Levelindex].kuang.Length];
		//如果当前关卡是没有答案的，选出三个地图放到待选框中
		if (!Levels [Levelindex].isHaveRightAnswer) {
			for (int i=0; i<Levels[Levelindex].kuang.Length; i++) {
				int shengindex = GetOneSheng ();
				Levels [Levelindex].shengfensprite [shengindex].transform.SetParent (Levels [Levelindex].kuang [i].transform);
				Levels [Levelindex].shengfensprite [shengindex].GetComponent<RectTransform> ().anchoredPosition = new Vector2 (0, -20);
				Levels [Levelindex].shengfensprite [shengindex].transform.DOScale (Vector3.one, 1);
				Levels [Levelindex].names [i].text = Levels [Levelindex].shengfenname [shengindex];
				nowshengindex [i] = shengindex;
			}
		} 
		else {
		//有答案的
			GetOneAnswer();
		}
		
		isbegin = true;
		//调用游戏开始的流程
		SendMessage ("MessageBegin");
	}
	//获取一个随机的未被使用地图的下标
	public int GetOneSheng()
	{
		int shengindex = Random.Range (0, ChoosenIndex.Count);
		shengindex=ChoosenIndex [shengindex];
		ChoosenIndex.Remove (shengindex);
		return shengindex;
	}
	int nowanswer=0;
	//获取一个未被使用的答案，其余待选框用非答案填充
	public void GetOneAnswer()
	{
		int kuangindex = Random.Range (0, Levels [Levelindex].kuang.Length);
		int oneanwser = Random.Range (0, Levels [Levelindex].answers.Count);
		oneanwser = Levels [Levelindex].answers [oneanwser];
		nowanswer = oneanwser;
		List<int> randomRange = new List<int> ();
		for (int i=0; i<ChoosenIndex.Count; i++)
			randomRange.Add (ChoosenIndex [i]);
		for (int i=0; i<Levels[Levelindex].kuang.Length; i++) {
			if(i==kuangindex)
			{
				Levels [Levelindex].shengfensprite [oneanwser].transform.SetParent (Levels [Levelindex].kuang [i].transform);
				Levels [Levelindex].shengfensprite [oneanwser].GetComponent<RectTransform> ().anchoredPosition = new Vector2 (0, -20);
				Levels [Levelindex].shengfensprite [oneanwser].transform.DOScale (Vector3.one, 1);
				Levels [Levelindex].names [i].text = Levels [Levelindex].shengfenname [oneanwser];
				nowshengindex [i] = oneanwser;
			}
			else
			{
				int one=Random.Range (0, randomRange.Count);
				one=randomRange[one];
				randomRange.Remove(one);
				Levels [Levelindex].shengfensprite [one].transform.SetParent (Levels [Levelindex].kuang [i].transform);
				Levels [Levelindex].shengfensprite [one].GetComponent<RectTransform> ().anchoredPosition = new Vector2 (0, -20);
				Levels [Levelindex].shengfensprite [one].transform.DOScale (Vector3.one, 1);
				Levels [Levelindex].names [i].text = Levels [Levelindex].shengfenname [one];
				nowshengindex [i] = one;
			}
		}
		randomRange = null;
	}
	//给当前没有地图的待选框补充一个地图，在没有答案时使用
	public void GetAnothersheng(int kuangindex)
	{
		if (ChoosenIndex.Count == 0) {
			Levels[Levelindex].names[kuangindex].enabled=false;
			return;
		}
		int shengindex=GetOneSheng();
		Levels[Levelindex].shengfensprite[shengindex].transform.SetParent(Levels[Levelindex].kuang[kuangindex].transform);
		Levels[Levelindex].shengfensprite[shengindex].GetComponent<RectTransform>().anchoredPosition=new Vector2(0,-20);
		Levels[Levelindex].shengfensprite[shengindex].transform.DOScale(Vector3.one,1);
		if (Nametype.text == "省") 
			Levels[Levelindex].names[kuangindex].text=Levels[Levelindex].shengfenname[shengindex];
		else if(Nametype.text == "行政中心")
			Levels[Levelindex].names[kuangindex].text=Levels[Levelindex].shenghuiname[shengindex];
		else if(Nametype.text == "简称")
			Levels[Levelindex].names[kuangindex].text=Levels[Levelindex].jianchengname[shengindex];
		nowshengindex [kuangindex] = shengindex;
	}
	public Text text_score;
	public Text text_time;
	public Text Nametype;
	//切换省的名称，省会和简称的显示
	public void ChangeNameType()
	{
		if (Nametype.text == "省") {
			for(int i=0;i<Levels[Levelindex].kuang.Length;i++)
			{
				Levels[Levelindex].names[i].text=Levels[Levelindex].shenghuiname[nowshengindex[i]];
				Nametype.text="行政中心";
			}
		}
		else if(Nametype.text == "行政中心") {
			for(int i=0;i<Levels[Levelindex].kuang.Length;i++)
			{
				Levels[Levelindex].names[i].text=Levels[Levelindex].jianchengname[nowshengindex[i]];
				Nametype.text="简称";
			}
		}
		else if(Nametype.text == "简称") {
			for(int i=0;i<Levels[Levelindex].kuang.Length;i++)
			{
				Levels[Levelindex].names[i].text=Levels[Levelindex].shengfenname[nowshengindex[i]];
				Nametype.text="省";
			}
		}
	}
	public Text shengtuState;
	//切换省图显示的开关
	public void ChangeShengtuState()
	{
		if (shengtuState.text == "开") {
			for(int i=0;i<Levels[Levelindex].shengfensprite.Length;i++)
			{
				Levels[Levelindex].shengfensprite[i].transform.FindChild("biao").GetComponent<Image>().enabled=true;
				Levels[Levelindex].shengfensprite[i].transform.FindChild("tu").GetComponent<Image>().enabled=false;
				shengtuState.text = "关";
			}
		}
		else if (shengtuState.text == "关") {
			for(int i=0;i<Levels[Levelindex].shengfensprite.Length;i++)
			{
				Levels[Levelindex].shengfensprite[i].transform.FindChild("biao").GetComponent<Image>().enabled=false;
				Levels[Levelindex].shengfensprite[i].transform.FindChild("tu").GetComponent<Image>().enabled=true;
				shengtuState.text = "开";
			}
		}
	}
	public void OnPointerDown(PointerEventData eventData)//鼠标按下
	{	
		#if !UNITY_EDITOR
		if(Input.touchCount>1)
			return;
		#endif
		if (isBacking) 
		{
			return;
		}
		nowItem = eventData.pointerCurrentRaycast.gameObject;
		//如果被点击的物体tag是item，克隆一个显示出来，放到临时父物体下面显示在最上层，跟随鼠标的位置，原位置的隐藏，记录下原来的位置
		if (nowItem.tag.Equals ("item")) 
		{
			nowitemClone = (GameObject)Instantiate (nowItem);
			nowitemClone.transform.position=nowItem.transform.position;
			nowItem.SetActive(false);
			PrePos = nowItem.transform.position;
			nowitemClone.name = nowItem.name;
			nowitemClone.transform.SetParent (m_initCanvas.transform, true);//临时父物体
			nowitemClone.transform.localScale = Vector3.one;
			nowitemClone.GetComponent<CanvasGroup> ().blocksRaycasts = false;//当前拖拽物体能被穿透
			nowkuangindex=GetNum(nowItem.transform.parent.name)[0];//获取当前拖拽物体所属的待选框序号
		} 
		else
		{
			nowItem = null;
			nowitemClone = null;
		}
	}
	private RectTransform rectTransform;//坐标
	public void OnDrag(PointerEventData eventData)//拖拽
	{
		if (isBacking) 
		{
			return;
		}
		//如果有拖拽物体，跟随鼠标，如果点击的手指超过一根，待选物体返回
		if (nowitemClone != null) {
			#if !UNITY_EDITOR
			if(Input.touchCount>1)
			{
				BackPrepos();
				return;
			}
			#endif
			nowitemClone.GetComponent<RectTransform> ().pivot.Set (0, 0);
			rectTransform = canvas.transform as RectTransform;
			Vector2 pos;
			if (RectTransformUtility.ScreenPointToLocalPointInRectangle (rectTransform, Input.mousePosition, canvas.worldCamera, out pos)) {
				nowitemClone.GetComponent<RectTransform> ().anchoredPosition = pos;
			}
		}
	}
	public void OnPointerUp(PointerEventData eventData)//手指抬起
	{
		#if !UNITY_EDITOR
		if(Input.touchCount>1)
		{
			BackPrepos();
			return;
		}
		#endif
		if (isBacking) 
		{
			return;
		}
		if (nowItem != null) {
			isBacking = true;
			//SendMessage ("MessageOnPointerUp", GetNum (nowItem.name));
			//如果抬起时在itemp上面
			if (eventData.pointerCurrentRaycast.gameObject != null && eventData.pointerCurrentRaycast.gameObject.tag == "itemp") 
			{
				//如果itemp的序号包含item的序号
				if (GetNum (eventData.pointerCurrentRaycast.gameObject.name).Contains(GetNum (nowItem.name)[0])) 
				{
					//如果当前关卡有答案且序号不包含在答案里面，按错误处理
					if(Levels[Levelindex].isHaveRightAnswer&&!Levels[Levelindex].answers.Contains(GetNum (nowItem.name)[0]))
					{
						DoWrong ();
					}
					else
					{
						Destroy (nowitemClone);
						DoRight (GetNum (nowItem.name)[0]);
					}
				} 
				else 
				{
					DoWrong ();
				}
			} 
			else 
			{
				isBacking=false;
				BackPrepos ();
			}
		}
	}
	private int rightcount=0;
	private void DoRight(int rightindex)////拖入物体正确的操作
	{
		nowItem=null;
		isBacking = false;
		//将对应序号的正确物体显示出来
		Levels[Levelindex].WhenRightShow [rightindex].gameObject.SetActive (true);
		if (Levels [Levelindex].isHaveRightAnswer) {
			StartCoroutine(RightWhenHaveAnswer());
		}
		else 
		{
			GetAnothersheng (nowkuangindex);
		}
		gamescore += 1000;
		text_score.text = gamescore.ToString ();
		SendMessage("MessageDoOneRight",rightindex);
		rightcount++;
		//如果全部答案完成或者全部地图完成
		if ((Levels[Levelindex].isHaveRightAnswer&&Levels[Levelindex].answers.Count==0)||rightcount == Levels [Levelindex].shengfensprite.Length) {
			isbegin = false;
			ChoosenIndex=null;
			SendMessage ("MessageDoAllRight");
			for (int i=0; i<Levels[Levelindex].shengfensprite.Length; i++) {
				Levels [Levelindex].shengfensprite [i].transform.SetParent (Daixuan.transform);
				Levels [Levelindex].shengfensprite [i].GetComponent<RectTransform> ().anchoredPosition = new Vector2 (0, 0);
				Levels [Levelindex].shengfensprite [i].transform.localScale = Vector3.zero;
				Levels [Levelindex].shengfensprite [i].SetActive(true);
			}
			if (Levelindex < Levels.Length)
				Levelindex++;
		}
	}
	//有答案时拖对一个之后的操作
	IEnumerator RightWhenHaveAnswer()
	{
		for (int i=0; i<nowshengindex.Length; i++) {
			Levels [Levelindex].shengfensprite [nowshengindex[i]].transform.DOScale(Vector3.zero,0.8f);
		}
		Levels [Levelindex].answers.Remove (nowanswer);
		if (Levels [Levelindex].answers.Count != 0) {
			yield return new WaitForSeconds (1);
			GetOneAnswer ();
		} 
		else 
		{
			for(int i=0;i<Levels[Levelindex].kuang.Length;i++)
				Levels[Levelindex].names[i].enabled=false;

		} 
	}
	private void DoWrong()//拖入物体错误的操作
	{
		SendMessage("MessageDoWrong",GetNum (nowItem.name)[0]);
		isBacking = false;
		BackPrepos ();
	}
	private void BackPrepos()//拖入错误时物体回到原来位置
	{
		if (isBacking) {
			return;
		}
		Tweener tweener = nowitemClone.GetComponent<RectTransform> ().DOMove (PrePos, 0.5f);
		isBacking = true;
		tweener.onComplete = delegate() {
			Destroy (nowitemClone);
			nowItem.SetActive(true);
			nowItem=null;
			isBacking=false;
		};
	}
	public void ChangelevelIndex(int index)
	{
		Levelindex = index;
	}
	public void ResetGameTime()
	{
		gametime = 0;
		text_time.text = "0";
	}
	public void ResetGameScore()
	{
		gamescore = 0;
		text_score.text="0";
	}
	//退出游戏
	public void ExitGame()
	{
		print ("ExitGame");
		#if !UNITY_EDITOR
		MDLog.Log("===ExitGame===");
		GameGlobal.m_gamecontrol.ResetParameterWhenBack ();
		#endif
	}
}
