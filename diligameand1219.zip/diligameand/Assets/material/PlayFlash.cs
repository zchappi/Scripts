using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
public class PlayFlash : MonoBehaviour {
	public bool isplayFlash=false;//是否播放flash
	public bool isplayAnimation=false;//是否播放animation   可以和flash同时播放
	public float fps = 25.0f; //flash的播放速度 
	public Sprite[] flashTextures;//flash图片 可以一键导入
	public bool loop;//是否循环 只控制flash
	public bool playonce;//是否播一次之后就算再次调用也不再播放 只控制flash
	public bool useTimeControl=false;//是否使用时间控制 
	public float PlayTime;//播放时间
	public bool hideWhenOver=false;//时间到后是否隐藏 需要先开启时间控制
	public GameObject Idle;//待机flash动画 如果不为空 当前flash播放结束后会自动显示idle物体并播放flash
	public GameObject[] OtherAnimation;//其他动画 当播放当前动画时会自动停止并隐藏其他动画
	private float hasplaytime=0;
	private float time = 0;
	private int currentIndex = 0;  
	bool isplaying=false;
	void FixedUpdate () 
	{
		if (isplaying) {
			time += Time.deltaTime;
			hasplaytime+= Time.deltaTime;
			if(isplayFlash)
			{
				gameObject.GetComponent<Image>().sprite=flashTextures[currentIndex];
				if (time >= 1.0f / fps)
				{
					time=0;
					currentIndex++;
					if (currentIndex >= flashTextures.Length)  
					{  
						if(!loop)
						{
							isplaying=false;
							currentIndex=0;
							if(playonce)
							{
								isplayFlash=false;
								isplayAnimation=false;
							}
							if(hideWhenOver)
							{
								gameObject.GetComponent<Image>().enabled=false;
								if(Idle)
								{
									Idle.GetComponent<Image>().enabled=true;
									if(Idle.GetComponent<PlayFlash>())
										Idle.GetComponent<PlayFlash>().Play();
								}
							}
						}
						else
							currentIndex = 0;  
					}  
				}
			}
			if(useTimeControl&&hasplaytime>=PlayTime)
			{
				isplaying=false;
				hasplaytime=0;
				if(isplayAnimation)
					gameObject.GetComponent<Animation>().Stop();

				gameObject.GetComponent<Image>().enabled=false;
				if(Idle)
				{
					Idle.GetComponent<Image>().enabled=true;
					if(Idle.GetComponent<PlayFlash>())
						Idle.GetComponent<PlayFlash>().Play();
				}
			}
			
		}
	}
//播放
	public void Play()
	{
		if (OtherAnimation.Length > 0) {
			for(int i=0;i<OtherAnimation.Length;i++)
			{
				OtherAnimation[i].GetComponent<PlayFlash>().stop();
			}
		}
		if(Idle)
		{
			Idle.GetComponent<Image>().enabled=false;
			if(Idle.GetComponent<PlayFlash>())
				Idle.GetComponent<PlayFlash>().stop();
		}

		if (isplayFlash) {
			currentIndex = 0;
		} 
		if (isplayAnimation) {
			gameObject.GetComponent<Animation>().Play();
		}
		gameObject.GetComponent<Image> ().enabled = true;
		isplaying = true;
	}
//停止
	public void stop()
	{
		if(isplayAnimation)
			gameObject.GetComponent<Animation>().Stop();
		if (isplayFlash) {
			gameObject.GetComponent<Image>().enabled=false;
			isplaying = false;
			currentIndex = 0;
			gameObject.GetComponent<Image>().sprite=flashTextures[0];
		}
		//gameObject.SetActive = false;
	}
}
