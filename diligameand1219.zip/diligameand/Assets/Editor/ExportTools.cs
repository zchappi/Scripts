﻿using UnityEditor;
using UnityEngine;


public class ExportTools
{
	
	[MenuItem("LittleGame/导出/ForAndroid")]
	static void ExportResourceAndroid ()
	{
		string path = EditorUtility.OpenFolderPanel ("SaveResource", "AssetBundles","");
		if (path.Length != 0) 
		{
			Object[] selection = Selection.GetFiltered(typeof(Object), SelectionMode.DeepAssets);
			
			foreach (UnityEngine.Object o in selection) {
				BuildPipeline.BuildAssetBundle (o, null, path + "/" + o.name + ".game", BuildAssetBundleOptions.CollectDependencies | BuildAssetBundleOptions.CompleteAssets, BuildTarget.Android);
			}
			
			Selection.objects = selection;
		}
	}

}
